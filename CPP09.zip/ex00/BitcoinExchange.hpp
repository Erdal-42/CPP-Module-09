/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   BitcoinExchange.hpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/02 18:28    by ekocak            #+#    #+#             */
/*   Updated: 2023/09/02 18:28    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ostream>
#include <iostream>
#include <map>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <limits>
#include "Date.hpp"

#define SourceFile  "data.csv"

class BitcoinExchange
{
    private:
        std::map<Date, float>   _container;    
    public:
        static Date StartDate;
        BitcoinExchange();
        BitcoinExchange(std::map<Date, float>);
        ~BitcoinExchange();
        BitcoinExchange(const BitcoinExchange&);
        BitcoinExchange& operator=(const BitcoinExchange&);
        const std::map<Date, float>&  getContainer() const;
        void    setContainer(std::map<Date, float>&);
        void    populateMap();
        void    traverseInputFile(std::string);
        float   findValue(Date&) const;
        float   calculateValue(Date, float);
};

Date BitcoinExchange::StartDate = Date(0,0,0);

int testDateValidity(Date&);
int testValueValidity(float&);