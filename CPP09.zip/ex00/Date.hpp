/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Date.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/02 18:28    by ekocak            #+#    #+#             */
/*   Updated: 2023/09/02 18:28    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ostream>
#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <limits>

class Date
{
    private:
        unsigned    _year;
        unsigned    _month;
        unsigned    _day;

    public:
        Date();
        Date(unsigned, unsigned, unsigned);
        ~Date();
        Date(const Date&);
        Date &operator=(const Date&);
        bool operator<(const Date&) const;
        bool operator>(const Date&) const;
        bool operator==(const Date&) const;
        unsigned    getYear() const;
        unsigned    getMonth() const;
        unsigned    getDay() const;
        void        decrement();
        bool        isLeap() const;
        bool        valid() const;
};

std::ostream& operator<<(std::ostream&, const Date&);
Date    *convertStrToDate(std::string);