/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   BitcoinExchange.cpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/02 18:28    by ekocak            #+#    #+#             */
/*   Updated: 2023/09/02 18:28    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "BitcoinExchange.hpp"


BitcoinExchange::BitcoinExchange() 
{}

BitcoinExchange::BitcoinExchange(std::map<Date, float> theContainer) : _container(theContainer)
{}

BitcoinExchange::~BitcoinExchange()
{}

BitcoinExchange::BitcoinExchange(const BitcoinExchange& other)
{
    _container = other._container;
}

BitcoinExchange& BitcoinExchange::operator=(const BitcoinExchange& other)
{
    if (this != &other)
    {
        _container.clear();
        std::map<Date, float>::const_iterator it = other._container.begin();
        while (it != other._container.end())
        {
            _container.insert(std::make_pair(it->first, it->second));
            it ++;
        }
    }
    return (*this);
}
 
const std::map<Date, float>&   BitcoinExchange::getContainer() const
{
    return _container;
}
        
void    BitcoinExchange::setContainer(std::map<Date, float>& theContainer)
{
    _container = theContainer;
}

/**
 * @brief Populate the Bitcoin data container from a source file.
 *
 * The source file is expected to be in CSV format, with each line 
 * containing date and value information separated by commas. It 
 * first reads and discards the header line of the CSV file since 
 * it is assumed to contain column headers and not data. Afterward, 
 * it iterates through each data line, extracting the date and value 
 * components, and inserts them into the container.
 * Additionally, it keeps track of the earliest date encountered 
 * during this process and updates the 'StartDate' static member 
 * variable accordingly.
 *
 * The function first attempts to open the source file and checks if 
 * it can be opened successfully. If the file cannot be opened, it 
 * prints an error message and returns without modifying the container.
 *
 * Finally, the input file is closed, and the function returns, leaving 
 * the container populated with Bitcoin data.
 *
 * @note This function assumes that the CSV file format is valid and 
 * adheres to the expected structure. If the file does not exist or 
 * cannot be opened, it logs an error message and returns without 
 * modifying the container.
 *
 * @see Date
 * @see convertStrToDate
 *
 * @param None.
 * @return None.
 */
void BitcoinExchange::populateMap()
{
    std::ifstream inputFile(SourceFile);
    if (!inputFile.is_open()) {
        std::cerr << "Error opening the source file: " << SourceFile << std::endl;
        return ;
    }
    std::string line;
    Date& sDate = StartDate;
    std::getline(inputFile, line);
    while (std::getline(inputFile, line)) 
    { 
        std::stringstream lineStream(line);
        std::string str_date;
        std::getline(lineStream, str_date, ',');
        const Date& date = *convertStrToDate(str_date);
        std::string str_value;
        std::getline(lineStream, str_value, ',');
        const float value = std::atof(str_value.c_str());
        _container.insert(std::make_pair(date, value));
        if (StartDate == Date(0,0,0))
            StartDate = date;
        if (date < sDate)
            sDate = date;
    }
    inputFile.close();
    StartDate = sDate;
}

/**
 * @brief Traverse and process data from an input file.
 *
 * This function reads and processes data from the referance
 * of a specified input file line by line. Each line is 
 * expected to contain date and value information separated 
 * by '|'. The function validates the input data, calculates 
 * a derived value based on the date and provided value, and 
 * prints the results. Errors are reported for invalid dates, 
 * non-positive values or values exceeding the maximum limit.
 *
 * If the date and value are valid, it calculates and prints 
 * the result using the 'calculateValue' function. Finally, 
 * the input file is closed.
 *
 * @param param The name of the input file to be processed.
 *
 * @details
 * The function opens the input file specified by 'param' and 
 * checks if it's successfully opened. If the file cannot be 
 * opened, it prints an error message and exits with a failure 
 * code.
 *
 * For each line in the input file, it extracts the date and 
 * value portions. It then validates the date, checks for 
 * non-positive values, and verifies that the value doesn't 
 * exceed the maximum limit. If any of these conditions are 
 * not met, corresponding error messages are printed.
 *
 * @see calculateValue
 *
 * @param param The name of the input file to be processed.
 */
void BitcoinExchange::traverseInputFile(std::string param)
{
    std::ifstream inputFile(param);
    if (!inputFile.is_open())
    {
        std::cerr << "Error: could not open file: " << param << std::endl;
        exit(EXIT_FAILURE);
    }
    std::string line;
    std::getline(inputFile, line);
    std::string str_date;
    std::string str_value;
    while (std::getline(inputFile, line)) 
    {
        std::stringstream lineStream(line);
        std::getline(lineStream, str_date, '|');
        Date& date = *convertStrToDate(str_date);
        std::getline(lineStream, str_value, '|');
        float fValue = std::atof(str_value.c_str());
        if (!testDateValidity(date))
            continue ;
        else if (!testValueValidity(fValue))
            continue ;
        else
            std::cout << date << " => " << fValue << " = " << calculateValue(date, fValue) << std::endl;
    }
    inputFile.close();
}
/*
 * @brief Find the Bitcoin value for a given date.
 *
 * This function searches for the Bitcoin value associated 
 * at a specific date in the internal data container. It 
 * takes a 'Date' object as input and tries to find a 
 * matching date in the container. If the date is found, the 
 * corresponding Bitcoin value is returned. If the date is 
 * not found in the container, it enters a loop to decrement 
 * the date until it finds a matching value or reaches the 
 * predefined 'StartDate'. If the date is not found at all, 
 * it prints an error message indicating that there is no 
 * data available for the specified date.
 *
 * @param date The 'Date' for which to find the Bitcoin value.
 * @return The Bitcoin value for the specified date, or 0 if 
 * the date is not found.
 */
float   BitcoinExchange::findValue(Date& date) const
{
    std::map<Date, float>::const_iterator it;
    while (1)
    {
        it = _container.find(date);
        if (it != _container.end()) 
            return (it->second);
        date.decrement();
    }
    return (0);
}            

/**
 * @brief Calculate the total value of a Bitcoin investment.
 *
 * This function calculates the total value of a Bitcoin 
 * investment made on a specified 'inputDate' based on the 
 * provided 'inputAmount'. It uses the 'findValue' function to
 * retrieve the Bitcoin value for the 'inputDate' and then 
 * multiplies it by the 'inputAmount' to determine the total 
 * value of the investment.
 *
 * @param inputDate The date of the Bitcoin investment.
 * @param inputAmount The amount of Bitcoin invested.
 * @return The total value of the Bitcoin investment.
 */
float   BitcoinExchange::calculateValue(Date inputDate, float inputAmount)
{
    return  (findValue(inputDate) * inputAmount);
}

/**
 * @brief Test the validity of a Date object.
 *
 * This function checks the validity of a given 'Date' 
 * object. If the date is not valid, it prints an error 
 * message indicating that  * the input date is invalid 
 * and returns 0. If the date is valid but falls before 
 * the predefined 'StartDate', it prints an error message 
 * indicating that the input date  * is too early and 
 * also returns 0. If the date is both valid and falls on 
 * or after the 'StartDate', it returns 1 to indicate a 
 * valid date.
 *
 * @param date The 'Date' object to be tested for validity.
 * @return 1 if the date is valid and not too early, 0 otherwise.
 */
int    testDateValidity(Date& date)
{
    if (!date.valid())
    {
        std::cout << "Error: bad input => " << date << std::endl;
        return (0);
    }
    else if (date < BitcoinExchange::StartDate)
    {
        std::cout << "Error: too early input => " << date << std::endl;
        return (0);
    }
    return (1);
}


/**
 * @brief Test the validity of a float value.
 *
 * This function tests the validity of a given float value. 
 * It checks whether the value is positive and within the 
 * range of a signed integer. If the value is negative, it
 * prints an error message indicating that it's not a
 * positive number and returns 0. If the value exceeds the 
 * maximum limit of a signed integer, it prints an error 
 * message indicating that it's too large, and also returns 
 * 0. If the value is valid (positive and within the allowed 
 * range), it returns 1.
 *
 * @param fValue The float value to be tested.
 * @return 0 if the value is not valid, 1 if the value is valid.
 */
int    testValueValidity(float& fValue)
{
    if (fValue < 0)
    {
        std::cout << "Error: not a positive number." << std::endl;
        return (0);
    }
    else if (fValue > std::numeric_limits<int>::max())
    {
        std::cout << "Error: too large a number." << std::endl;
        return (0);
    }
    return (1);
}


