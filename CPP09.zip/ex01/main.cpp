#include "RPN.hpp"

bool    isInteger(const std::string& param)
{
    const char *str = param.c_str();
    if (*str && *str == '-')
        ++ str;
    while (*str)
    {
        if (*str < '0' || *str > '9')
            return (false);
        str ++;
    }
    return (true);
}

bool    isOperator(const std::string& param)
{
    //const char *str = param.c_str();
    std::string OPERATORS = "+*-/";
    if (param.length() == 1 && (OPERATORS.find(param[0]) != std::string::npos))
    {
        return (true);
    }
    return (false);    
}


/**
 * @brief Tests a token for validity.
 *
 * This function checks if a given token is valid by attempting to convert 
 * it to an integer and checking for the presence of parentheses 
 * ('(' or ')'). If the token is not a valid integer and contains parentheses, 
 * it throws a MyException with an error message.
 *
 * @param token The token to be tested for validity.
 *
 * @throws MyException if the token is not a valid integer and contains parentheses.
 *
 * @return true if the token is valid, false otherwise.
 */
bool testToken(std::string token)
{
    std::string zero = "0";
    std::istringstream iss(token);

    try
    {
        // Check if it's not a valid integer and contains parentheses.
        if (!isInteger(token) && (token.find('(') != std::string::npos || token.find(')') != std::string::npos))
            throw MyException("Error: Brackets are not managed.");
        else if (!isInteger(token) && !isOperator(token))
            throw MyException("Error: Algebraic and decimal numbers are not managed.");
    }
    catch (std::exception& e)
    {
        std::cout << e.what() << std::endl;
        return false;
    }

    // Return true if the token is valid.
    return true;
}

/**
 * @brief Validates the input string based on RPN expression rules.
 *
 * This function validates an input string according to the rules of a 
 * Reverse Polish Notation (RPN) expression. It tokenizes the input 
 * string and checks if the tokens are valid integers and operators in 
 * the correct sequence. After the first integer, starting with the 
 * second token, odd-positioned tokens are expected to be integers, 
 * while even-positioned tokens ought to be operators 
 * ('+', '-', '*', '/'). If any token is found to be invalid or if the 
 * sequence of tokens is incorrect, the function returns false.
 *
 * @param param The input string to be validated as an RPN expression.
 *
 * @return true if the input string is a valid RPN expression, false 
 * otherwise.
 */
bool validity(const std::string& param) 
{
    std::istringstream lineStream(param);
    std::string token;
    std::string zero = "0";
    lineStream >> token;
    int flag = 1;
    
    // Check the validity of the first token.
    if (!testToken(token))
        return false;
    while (lineStream >> token) 
    {
        // Check the validity of the odd token following the first token.
        if (!testToken(token))
            return false;
        if (!(flag % 2))
        {
            std::string OPERATORS = "+*-/";

            // Check if the token is a valid operator.
            if (!testToken(token) || token.length() != 1 || OPERATORS.find(token[0]) == std::string::npos) 
            {
                std::cout << zero << std::endl;
                return false;
            }
        }
        flag++;
    }

    // Check if there are enough tokens.
    if (flag < 3) 
    {
        std::cout << zero << std::endl;
    }

    // Return true if the input string is a valid RPN expression.
    return (flag > 2) && (flag % 2);
}

/**
 * @brief Main function for evaluating Reverse Polish Notation (RPN) 
 * expressions.
 *
 * This function parses command line arguments, validates the input as an 
 * RPN expression, calculates the result, and prints it to the standard 
 * output. If any errors occur during validation or calculation, error 
 * messages are printed to the standard error stream.
 *
 * @param argc The number of command line arguments.
 * @param argv An array of strings representing the command line 
 * arguments.
 *
 * @return 0 on successful execution, 1 on validation or calculation 
 * errors.
 */
int main(int argc, char **argv)
{
    if (argc != 2)
    {
        std::cerr << "Error: Invalid number of parameters.\n" << std::endl; 
        return (1);
    }
    if (!validity(argv[1]))
        return (1);
    RPN rpn;    
    rpn.populateQueues(argv[1]);
    try
    {
        std::cout << rpn.conductCalculation() << std::endl;
    } catch (std::exception &e)
    {
        std::cerr << e.what() << std::endl;
    }
    return (0);
}