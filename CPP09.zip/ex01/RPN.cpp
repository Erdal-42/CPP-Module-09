#include "RPN.hpp"

MyException::MyException(const std::string& message) : message_(message)
{}

const char  *MyException::what() const throw()
{
    return message_.c_str();
}

RPN::RPN()
{}
        
RPN::RPN(std::queue<int> iQueue, std::queue<char> oQueue) 
                        : _integerQueue(iQueue), _operatorQueue(oQueue)
{}

RPN::~RPN()
{}

RPN::RPN(const RPN& other)
{
    _integerQueue = other._integerQueue;
    _operatorQueue = other._operatorQueue;
}
        
RPN& RPN::operator=(const RPN& other)
{
    if (this != &other)
    {
        while (!_integerQueue.empty())
            _integerQueue.pop();
        std::queue<int> int_copy = other._integerQueue;     // Create a copy
        while (!int_copy.empty())
        {
            _integerQueue.push(int_copy.front());
            int_copy.pop();
        }

        while (!_operatorQueue.empty())
            _operatorQueue.pop();
        std::queue<char> op_copy = other._operatorQueue;     // Create a copy
        while (!op_copy.empty())
        {
            _operatorQueue.push(op_copy.front());
            op_copy.pop();
        }
    }
    return (*this);
}

std::queue<int> RPN::getIntegerQueue() const
{
    return (_integerQueue);
}

std::queue<char> RPN::getOperatorQueue() const
{
    return (_operatorQueue);
}

std::ostream& operator<<(std::ostream& os, const RPN& rpn) 
{
    std::queue<int> int_copy = rpn.getIntegerQueue();     // Create a copy
    std::queue<char> op_copy = rpn.getOperatorQueue();    // Create a copy

    if (!int_copy.empty())
    {
        os << int_copy.front();
        int_copy.pop();
    }
    while (!op_copy.empty())
    {
        os << " ";
        if (!int_copy.empty())
        {
            os << int_copy.front();
            int_copy.pop();
        }
        os << " " << op_copy.front();
        op_copy.pop();    
    }
    return os;
}


/**
 * @brief Populates the integer and operator queues with tokens extracted 
 * from the input string.
 *
 * This function tokenizes the already validated input string using 
 * whitespace as the delimiter and populates the integer and operator 
 * queues based on the token type and position in the input string. First 
 * token is an integer and the following tokens are altenatingly integer
 * and operator. Hence after the first token, odd-positioned tokens are 
 * assumed to be integers and are pushed into the integer queue, while 
 * even-positioned tokens are assumed to be operators and are pushed into 
 * the operator queue.
 *
 * @param param The input string to be tokenized and used to populate the 
 * queues.
 */

void RPN::populateQueues(std::string param)
{
    // Initialize a stringstream to tokenize the input string.
    std::istringstream lineStream(param);

    // Initialize variables to store tokens.
    std::string token;
    //this line copies the first token into token 
    lineStream >> token;
    //a second stream iss1 is declared and initialised with only token 
    std::istringstream iss1(token);
    int i;
    //This line attempts to extract an integer from the iss1 stringstream 
    //and store it in the i variable.
    iss1 >> i;

    // Push the first integer onto the integer queue.
    _integerQueue.push(i);

    // Initialize a flag to keep track of the token position.
    int flag = 1;

    // Continue iterating tokens and populating queues while 
    //there are more tokens.
    while (lineStream >> token)
    {
        if (flag % 2)
        {
            // Odd-positioned tokens are assumed to be integers.
            std::istringstream iss1(token);
            iss1 >> i;
            _integerQueue.push(i);
        }
        else
        {
            // Even-positioned tokens are assumed to be operators.
            _operatorQueue.push(token[0]);
        }
        flag++;
    }
}

/**
 * @brief Calculates the result of the Reverse Polish Notation (RPN) 
 * expression.
 *
 * This function evaluates the RPN expression stored in the integer 
 * and operator queues and returns the result.
 * It iterates through the operator queue and applies each operator 
 * to the integers in the integer queue based on their positions.
 *
 * @throws std::runtime_error if division by zero is encountered.
 *
 * @return The result of the RPN expression.
 */

int    RPN::conductCalculation()
{
    int total = _integerQueue.front();
    _integerQueue.pop();
    while (!_integerQueue.empty())
    {
        char    op = _operatorQueue.front();
        if (op == '+')
            total += _integerQueue.front();
        else if (op == '-')
            total -= _integerQueue.front();
        else if (op == '*')
            total *= _integerQueue.front();
        else if (op == '/')
        {
            if (_integerQueue.front() == 0)
                throw std::runtime_error("Error: Division by 0.");
            else
                total /= _integerQueue.front();
        }
        _operatorQueue.pop();
        _integerQueue.pop();
    }
    return (total);
}