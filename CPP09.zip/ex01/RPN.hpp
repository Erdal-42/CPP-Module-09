#include <algorithm>
#include <queue>
#include <ostream>
#include <iostream>
#include <sstream>
#include <exception>
#include <string>


class MyException : public std::exception
{
public:
    MyException(const std::string&);
    virtual const char* what() const throw();

private:
    std::string message_;
};

class RPN
{
    private:
        std::queue<int>     _integerQueue;
        std::queue<char>    _operatorQueue;
    public:
        RPN();
        RPN(std::queue<int>, std::queue<char>);
        ~RPN();
        RPN(const RPN&);
        RPN& operator=(const RPN&);
        std::queue<int> getIntegerQueue() const;
        std::queue<char> getOperatorQueue() const;
        void    populateQueues(std::string);
        int     conductCalculation();
};

std::ostream& operator<<(std::ostream&, const RPN&);